<?php

declare(strict_types=1);

namespace Smartosc\Banner\Block\Adminhtml;

use Amasty\Base\Model\Serializer;
use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Json\EncoderInterface;
use Magento\Payment\Model\Config as PaymentConfig;
use Smartosc\Banner\Model\Source\Website as SourceWebsite;

class Records extends Field
{
    const WEBSITE_IDS = 'website_ids';

    /**
     * @var EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @var Serializer
     */
    protected $serializer;

    /**
     * @var PaymentConfig
     */
    protected $paymentConfig;

    /**
     * @var SourceWebsite
     */
    protected $sourceWebsite;

    public function __construct(
        Context $context,
        EncoderInterface $jsonEncoder,
        Serializer $serializer,
        PaymentConfig $paymentConfig,
        SourceWebsite $sourceWebsite,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->jsonEncoder = $jsonEncoder;
        $this->serializer = $serializer;
        $this->paymentConfig = $paymentConfig;
        $this->sourceWebsite = $sourceWebsite;
    }

    protected function _construct()
    {
        $this->setTemplate('Smartosc_Banner::/records.phtml');
    }

    /**
     * @param AbstractElement $element
     * @return string
     */
    public function render(AbstractElement $element)
    {
        $this->setElement($element);

        return $this->_decorateRowHtml($element, $this->_toHtml());
    }

    /**
     * @return array
     */
    public function getSelectedRecords(): array
    {
        $records = $this->getElement()->getValue() ?: [];
        if (isset($records[0]) && empty($records[0])) {
            $records = [];
        }

        return $records;
    }

    /**
     * @return array
     */
    public function getDefaultRecords(): array
    {
        return [
            self::WEBSITE_IDS => $this->getWebsiteIds(),
        ];
    }

    /**
     * @return array
     */
    public function getWebsiteIds(): array
    {
        $ids = $this->sourceWebsite->toOptionArray();

        return $ids ?? [];
    }

    /**
     * @return bool|string
     */
    public function getInitData()
    {
        return $this->serializer->serialize(
            [
                'namePrefix' => $this->getNamePrefix('#'),
                self::WEBSITE_IDS => $this->getWebsiteIds(),
            ]
        );
    }

    /**
     * @param int $index
     * @param int|null $counter
     * @return string
     */
    public function getNamePrefix($index, $counter = null)
    {
        $name = str_replace('[]', '', $this->getElement()->getName());
        $name .= $counter !== null ? '[' . $counter . ']' : '';

        return $name . '[' . $index . ']';
    }
}
