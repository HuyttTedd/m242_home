var config = {
    map: {
        "*": {
            "bannerRecords": "Smartosc_Banner/js/components/banner-records",
        }
    }
};
